import React from 'react';

interface QuantumBankLogoProps {
  size?: number;
  className?: string;
  animated?: boolean;
}

export const QuantumBankLogo: React.FC<QuantumBankLogoProps> = ({ 
  size = 200, 
  className = '',
  animated = true 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 200 200" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Quantum Bank Logo"
    >
      <defs>
        <linearGradient id="quantumGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style={{ stopColor: '#a78bfa', stopOpacity: 1 }} />
          <stop offset="50%" style={{ stopColor: '#8b7ff4', stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: '#6366f1', stopOpacity: 1 }} />
        </linearGradient>
        
        <filter id="glow">
          <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
          <feMerge>
            <feMergeNode in="coloredBlur"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
        
        <filter id="strongGlow">
          <feGaussianBlur stdDeviation="5" result="coloredBlur"/>
          <feMerge>
            <feMergeNode in="coloredBlur"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
      </defs>
      
      {/* The "0" - left side, slightly transparent */}
      <circle 
        cx="85" 
        cy="100" 
        r="45" 
        fill="none" 
        stroke="url(#quantumGradient)" 
        strokeWidth="8" 
        opacity="0.7"
        filter="url(#glow)" 
      />
      
      {/* The "1" - subtle tilt with matching serifs */}
      <g opacity="0.7" filter="url(#glow)">
        <rect 
          x="123" 
          y="52" 
          width="8" 
          height="90" 
          fill="url(#quantumGradient)" 
          rx="4"
          transform="rotate(8 127 97)" 
        />
        <rect 
          x="103" 
          y="52" 
          width="32" 
          height="8" 
          fill="url(#quantumGradient)" 
          rx="4"
          transform="rotate(8 119 56)" 
        />
        <rect 
          x="103" 
          y="134" 
          width="32" 
          height="8" 
          fill="url(#quantumGradient)" 
          rx="4"
          transform="rotate(8 119 138)" 
        />
      </g>
      
      {/* Superposition overlap area - the quantum magic! */}
      <ellipse 
        cx="107" 
        cy="100" 
        rx="18" 
        ry="45" 
        fill="url(#quantumGradient)" 
        opacity="0.3"
        filter="url(#strongGlow)" 
      />
      
      {/* Quantum particles/dots for extra effect */}
      {animated ? (
        <>
          <circle cx="100" cy="80" r="2" fill="#c4b5fd" opacity="0.8">
            <animate 
              attributeName="opacity" 
              values="0.8;0.3;0.8" 
              dur="2s" 
              repeatCount="indefinite" 
            />
          </circle>
          <circle cx="110" cy="100" r="2" fill="#c4b5fd" opacity="0.6">
            <animate 
              attributeName="opacity" 
              values="0.6;0.3;0.6" 
              dur="2.5s" 
              repeatCount="indefinite" 
            />
          </circle>
          <circle cx="105" cy="120" r="2" fill="#c4b5fd" opacity="0.7">
            <animate 
              attributeName="opacity" 
              values="0.7;0.3;0.7" 
              dur="3s" 
              repeatCount="indefinite" 
            />
          </circle>
        </>
      ) : (
        <>
          <circle cx="100" cy="80" r="2" fill="#c4b5fd" opacity="0.6" />
          <circle cx="110" cy="100" r="2" fill="#c4b5fd" opacity="0.5" />
          <circle cx="105" cy="120" r="2" fill="#c4b5fd" opacity="0.6" />
        </>
      )}
    </svg>
  );
};

export default QuantumBankLogo;
